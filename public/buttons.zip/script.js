const buttonHeight = 50;
const buttonWidth = 150;

window.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('button');
    const container = document.querySelector('.container');

    const containerWidth = 400;
    const containerHeight = 670;

    button.addEventListener('click', () => alert('Please na baby 🥺🥺'));
    // button.addEventListener('click', () => alert('Please buy it!! 🥺🥺'));

    button.addEventListener('mouseover', () => {
        const maxWidth = containerWidth - buttonWidth;
        const maxHeight = containerHeight - buttonHeight;

        const newLeft = Math.floor(Math.random() * maxWidth);
        const newTop = Math.floor(Math.random() * maxHeight);

        // Ensure the button stays within the container
        button.style.left = newLeft + 'px';
        button.style.top = newTop + 'px';
    });
});




